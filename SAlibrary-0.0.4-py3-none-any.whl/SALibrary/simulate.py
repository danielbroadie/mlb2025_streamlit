
# coding: utf-8

# In[ ]:


from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import SALibrary.SimpleRatingSystem as srs
import scipy
from scipy.stats import norm
import time
from operator import attrgetter
import matplotlib.pyplot as plt


def MonteCarlo(func,schedule,standings,trials = 1000):

    '''function to get standings and schedule_temp based off of SRS

    Args:
        func: function
            simulation function
        schedule: dataframe
            schedule_temp of games with these columns: Week, playoff_game, away team, home team, and home margin
        standings: dataframe
            current standings
        trials:
            number of trials
    Return:
        a simulation of values for the given number of trials
    '''


    startT = time.time()

    tmp = func(schedule,standings)
    simuOutput = pd.DataFrame(index=tmp.index)
    tmp.name = '0'
    simuOutput = simuOutput.join(tmp)

    for eachTrial in range(trials-1):
        tmp = func(schedule,standings)
        tmp.name = str(eachTrial+1)
        simuOutput = simuOutput.join(tmp)

        if (eachTrial+1) % 50 == 0:
            print('Trials:',eachTrial+1)

    simuOutput = simuOutput.astype(float)
    simuSummary = pd.DataFrame(index=simuOutput.index)
    simuSummary['average'] = simuOutput.mean(axis=1)
    simuSummary['standard deviation'] = simuOutput.std(axis=1)
    simuSummary['standard error'] = simuOutput.sem(axis=1)
    simuSummary['minimum'] = simuOutput.min(axis=1)
    simuSummary['maximum'] = simuOutput.max(axis=1)
    simuSummary['1% percentile'] = simuOutput.quantile(q=0.01,axis=1)
    simuSummary['5%'] = simuOutput.quantile(q=0.05,axis=1)
    simuSummary['10%'] = simuOutput.quantile(q=0.1,axis=1)
    simuSummary['50%'] = simuOutput.quantile(q=0.5,axis=1)
    simuSummary['90%'] = simuOutput.quantile(q=0.9,axis=1)
    simuSummary['95%'] = simuOutput.quantile(q=0.95,axis=1)
    simuSummary['99%'] = simuOutput.quantile(q=0.99,axis=1)

    print('CPU seconds ',time.time()-startT)
    return simuSummary


def scrapeSRSSimulate_NFL(year, weeks_blocked,
                          home_advantage = 0, num_simulations = 1000):

    '''function to get standings and schedule_temp based off of SRS

    Args:
        year: int
            year to simulate
        weeks_blocked: list
            weeks to put in test set
        home_advantage: float
            home field advantage for team
        num_simulations: int
            number of simulations
    Return:
        probabilities each team makes the playoffs for given year
    '''

    #scrape pro-football reference for schedule and standings
    schedule, standings = scrape_nfl(year)

    #do SRS and add game probabilites
    schedule_probs, standings_probs, ratings = probability_games(schedule, standings, weeks_blocked, playoffs = 0)

    #plott the binned stats
    plot_binned_stats(schedule_probs)


    #simulate some result
    sim_results = MonteCarlo(simulate_nfl, schedule_probs, standings, num_simulations)


    #sort the results
    sim_results = sim_results.sort_values('average', ascending = 0)
    ratings = ratings.sort_values('Rating', ascending = 0)


    return sim_results, ratings



def scrape_nfl(yearSeasonStart):
    '''function to scrape website: "https://www.pro-football-reference.com/years/{year}/games.htm"

    Args:
        yearSeasonStart: int
            the start year of a season user want to scrape

    Return:
        pandas dataframe of game schedules and scores
    '''

    #URL to scrape schedule
    url_template = "https://www.pro-football-reference.com/years/{year}/games.htm"

    #loading HTML
    url = url_template.format(year=yearSeasonStart)  # get the url
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')

    #getting column names for schedule dataframe
    column_headers = [th.getText() for th in soup.findAll('thead', limit=1)[0].findAll('th')]

    #getting rows
    data_rows = soup.findAll('tbody', limit=1)[0].findAll('tr')[0:]

    #getting data from schedule
    schedule_data = [[td.getText() for td in data_rows[i].findAll(['th','td'])]  for i in range(len(data_rows))]

    #creating dataframe
    schedule = pd.DataFrame(schedule_data, columns=column_headers)

    #removing empty rows / playoff games
    schedule = schedule.loc[((schedule.Week != "Week") &
                           (schedule.Date != "Playoffs"))]


    #adding indicator for playoffs
    schedule['playoff_game'] = ((schedule.Week == "Playoffs") |
                           (schedule.Week == "WildCard") |
                           (schedule.Week == "Division") |
                           (schedule.Week == "ConfChamp") |
                           (schedule.Week == "SuperBowl"))

    #reseting index
    schedule = schedule.reset_index(drop = True)

    #selecting and renaming columns
    schedule = schedule[['Winner/tie', '', 'Loser/tie', 'PtsW', 'PtsL', 'Week', 'playoff_game']]
    schedule.columns = ["Winner/tie", 'at', 'boxscore', 'Loser/tie', 'PtsW', 'PtsL', 'Week', 'playoff_game']

    #making 'at' indicator for home / away team
    schedule['at'] = schedule['at'] == "@"

    #extracting home / away teams
    schedule['away team'] = schedule['Winner/tie'] * schedule['at'] + schedule['Loser/tie'] * (1 -  schedule['at'])
    schedule['home team'] = schedule['Loser/tie'] * schedule['at'] + schedule['Winner/tie'] * (1 -  schedule['at'])


    #Setting to -1 temporarily so it will not be string, later turned to NaN
    schedule.loc[(schedule.PtsW == ''),'PtsW'] = -1
    schedule.loc[(schedule.PtsL == ''),'PtsL'] = -1



    #getting home margin
    schedule['PtsW'] = schedule['PtsW'].astype(int)
    schedule.loc[schedule.PtsW == -1, 'PtsW'] = np.nan

    schedule['PtsL'] = schedule['PtsL'].astype(int)
    schedule.loc[schedule.PtsL == -1, 'PtsL'] = np.nan

    schedule['home margin'] = ((schedule['PtsW'] - schedule['PtsL']) *
                                      (-1 * schedule['at'] + (1 -  schedule['at'])))

    #selecting relevant columns
    schedule = schedule[['Week', 'playoff_game', 'away team', 'home team', 'home margin']]


    #url standings
    url_template = "https://www.pro-football-reference.com/years/{year}/"

    #getting HTML for standings
    url = url_template.format(year=yearSeasonStart)
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')

    #getting AFC standings
    column_headers_afc = [th.getText() for th in soup.findAll('thead', limit=1)[0].findAll('th')]
    data_rows_afc = soup.findAll('tbody', limit=1)[0].findAll('tr')[0:]
    standings_data_afc = [[td.getText() for td in data_rows_afc[i].findAll(['th','td'])]  for i in range(len(data_rows_afc))]

    #getting NFC standings
    column_headers_nfc = [th.getText() for th in soup.findAll('thead', limit=2)[1].findAll('th')]
    data_rows_nfc = soup.findAll('tbody', limit=2)[1].findAll('tr')[0:]
    standings_data_nfc = [[td.getText() for td in data_rows_nfc[i].findAll(['th','td'])]  for i in range(len(data_rows_nfc))]


    # Turn yearly data into a DataFrame
    standings_afc = pd.DataFrame(standings_data_afc, columns=column_headers_afc)
    standings_nfc = pd.DataFrame(standings_data_nfc, columns=column_headers_nfc, index = np.arange(len(data_rows_afc),
                                                                                             len(data_rows_nfc) +
                                                                                             len(data_rows_afc)))

    #appending standings
    standings = standings_afc.append(standings_nfc)


    #extracting divisions from rows (Will have null in W column if it is a division name)
    divisions = standings.loc[standings['W'].isnull()][["Tm"]]
    divisions.columns = ["division"]

    #remvoing divisions (Will have null in W column if it is a division name)
    standings = standings.loc[(~standings['W'].isnull())]

    #merging divisons back on
    standings = pd.merge(standings,
             divisions, how = 'outer', left_index = True, right_index = True)




    #filling NA info
    standings['division'] = standings['division'].fillna(method = "ffill")


    #dropping NA
    standings = standings.dropna()

    standings = standings.reset_index(drop = True)

    #checking if tie occured in season
    if not ('T' in standings.columns):
        standings['T'] = 0

    standings = standings[['Tm', 'W', 'L', 'T', 'division']]

    standings['Tm'] = standings['Tm'].str.replace('[^A-Za-z0-9- ]', '')

    standings['conference'] = standings['division'].str[0:4]

    standings = standings.set_index('Tm')

    standings['W'] = standings['W'].astype(int)

    standings['L'] = standings['L'].astype(int)

    standings['T'] = standings['T'].astype(int)

    #returning schedule and standings
    return schedule, standings




def probability_games(schedule, standings, weeks_blocked, playoffs = 0, home_advantage = 0):
    '''function to get standings and schedule_temp based off of SRS

    Args:
        schedule: dataframe
            schedule_temp of games with these columns: Week, playoff_game, away team, home team, and home margin
        standings: dataframe
            current standings
        weeks_blocked: list
            weeks that are placed in test set
        playoffs: boolean
            whether or not the playoffs should be included
        home_advantage:
            home advantage for SRS

    Return:
        pandas dataframe of game schedule and standings with updated ratings and probabilities
    '''

    #making copies of values
    standings_temp = standings.copy()
    schedule_temp = schedule.copy()


    #making indicators win / tie
    schedule_temp['away_win'] = schedule_temp['home margin'] < 0
    schedule_temp['home_win'] = schedule_temp['home margin'] > 0
    schedule_temp['tie'] = schedule_temp['home margin'] == 0

    #checking if playoff games are to be included
    if not playoffs:
        schedule_temp = schedule_temp.loc[schedule_temp.playoff_game == False]


    #getting list of teams
    num_teams = len(np.unique(list(schedule_temp['home team']) + list(schedule_temp['away team'])))


    #marking weeks that are "missing as NA"
    try:

        for week in weeks_blocked:

            schedule_temp.loc[schedule_temp.Week == str(week), 'home margin'] = np.nan

    #if only one week is passed
    except:

        weeks_blocked = [weeks_blocked, weeks_blocked + 1]

        for week in weeks_blocked:

            schedule_temp.loc[schedule_temp.Week == str(week), 'home margin'] = np.nan



    #resetting standings
    standings_temp['W'] = 0
    standings_temp['L'] = 0
    standings_temp['T'] = 0



    #Adding wins / losses / ties to standings
    standings_temp['W'] = standings_temp['W'] + schedule_temp.groupby('away team')['away_win'].apply(lambda x: sum(x.fillna(0)))
    standings_temp['L'] = standings_temp['L'] + schedule_temp.groupby('away team')['home_win'].apply(lambda x: sum(x.fillna(0)))

    standings_temp['W'] = standings_temp['W'] + schedule_temp.groupby('home team')['home_win'].apply(lambda x: sum(x.fillna(0)))
    standings_temp['L'] = standings_temp['L'] + schedule_temp.groupby('home team')['away_win'].apply(lambda x: sum(x.fillna(0)))

    standings_temp['T'] = standings_temp['T'] + schedule_temp.groupby('away team')['tie'].apply(lambda x: sum(x.fillna(0)))
    standings_temp['T'] = standings_temp['T'] + schedule_temp.groupby('home team')['tie'].apply(lambda x: sum(x.fillna(0)))


    schedule_temp_so_far = schedule_temp.dropna()

    ratings, rmse = srs.srs_opt(schedule_temp_so_far, rating_init = pd.DataFrame(np.zeros(num_teams)),
                                homeAdvantage = home_advantage)

    schedule_temp = pd.merge(schedule_temp, ratings, left_on = ["home team"], right_index = True)
    schedule_temp = pd.merge(schedule_temp, ratings, left_on = ["away team"], right_index = True, suffixes = ["_home",
                                                                                                   "_away"])

    #calculating predictinos and probabilities
    schedule_temp['pred margin'] = schedule_temp['Rating_home'] - schedule_temp['Rating_away']

    schedule_temp['prob_home'] = 1 - scipy.stats.norm(schedule_temp['pred margin'], rmse).cdf(0)



    return schedule_temp, standings_temp, ratings



def simulate_nfl(schedule, standings):
    '''function to get standings and schedule_temp based off of SRS

    Args:
        schedule: dataframe
            schedule_temp of games with these columns: Week, playoff_game, away team, home team, and home margin
        standings: dataframe
            current standings
    Return:
        a simulation of whether or not a given team made the playoffs
    '''

    schedule_temp = schedule.copy()

    standings_temp = standings.copy()

    num_playoff_spots = 12
    num_conferences = 2


    #number of games remaining
    games_remaining = len(schedule_temp)
    num_teams = len(standings_temp)

    #unique teams
    unique_teams = np.unique(list(schedule_temp['home team']) + list(schedule_temp['away team']))

    num_nfl_games = len(schedule)/len(unique_teams)

    #dataframe to store results
    results = pd.DataFrame(index = unique_teams, columns = ['winDivisionPercentage',
                                                           'winWildCardPercentage',
                                                           'makePlayoffsPercentage'],
                          data = np.zeros((len(unique_teams), 3)))



    #generating a random value for each game
    rand_vals = np.random.random(games_remaining)


    #determining home / away wins
    schedule_temp['home_win'] = (schedule_temp['prob_home'] > rand_vals).astype(int)
    schedule_temp['away_win'] = 1 - schedule_temp['home_win']


    #Adding wins / losses to standings
    standings_temp['W'] = standings_temp['W'] + schedule_temp.groupby('away team')['away_win'].apply(lambda x: sum(x))
    standings_temp['L'] = standings_temp['L'] + schedule_temp.groupby('away team')['home_win'].apply(lambda x: sum(x))

    standings_temp['W'] = standings_temp['W'] + schedule_temp.groupby('home team')['home_win'].apply(lambda x: sum(x))
    standings_temp['L'] = standings_temp['L'] + schedule_temp.groupby('home team')['away_win'].apply(lambda x: sum(x))

    #calculating win percentage based off wins and ties
    standings_temp['win_percent'] = (standings_temp['W'] + standings_temp['T'] * 0.5)/num_nfl_games * 100

    #adding epsilon to break ties randomly
    standings_temp['win_percent'] = standings_temp['win_percent'] + np.random.random(num_teams) * 0.001

    #calculating division rank
    standings_temp['divisionRank'] = standings_temp.groupby('division')[['win_percent']].rank(ascending = False)

    #indicator measuring who won division
    standings_temp['wonDivision'] = standings_temp['divisionRank'] == 1

    #rank as wildcard team
    standings_temp['wildCardRank'] = standings_temp.loc[standings_temp.wonDivision ==
                                    0].groupby(['conference'])['win_percent'].rank(ascending = False)

    #indicator determining whether team won wild card
    num_wildcard_spots = int((num_playoff_spots - sum(standings_temp['wonDivision']))/(num_conferences))

    standings_temp['wonWildCard'] = 0

    for wild_card_rank in range(num_wildcard_spots + 1):
        standings_temp['wonWildCard'] = ((standings_temp['wildCardRank'] == wild_card_rank) |
                                         (standings_temp['wonWildCard']))

    #indicator determing whether team made playoffs
    standings_temp['made_playoffs'] = standings_temp['wonWildCard'] | standings_temp['wonDivision']


    return standings_temp['made_playoffs']



def simulate_mlb(schedule, standings):
    '''function to get standings and schedule_temp based off of SRS

    Args:
        schedule: dataframe
            schedule_temp of games with these columns: Week, playoff_game, away team, home team, and home margin
        standings: dataframe
            current standings
    Return:
        a simulation of whether or not a given team made the playoffs
    '''

    schedule_temp = schedule.copy()

    standings_temp = standings.copy()

    num_conferences = 2


    #number of games remaining
    games_remaining = len(schedule_temp)
    num_teams = len(standings_temp)

    #unique teams
    unique_teams = np.unique(list(schedule_temp['home team']) + list(schedule_temp['away team']))

    num_mlb_games = len(schedule)/len(unique_teams)

    #dataframe to store results
    results = pd.DataFrame(index = unique_teams, columns = ['winDivisionPercentage',
                                                           'winWildCardPercentage',
                                                           'makePlayoffsPercentage'],
                          data = np.zeros((len(unique_teams), 3)))

    #generating a random value for each game
    rand_vals = np.random.random(games_remaining)

    #determining home / away wins
    #print(schedule_temp)
    not_played_yet = schedule_temp['away score'].isnull()
    schedule_temp.loc[not_played_yet,'home_win'] = (schedule_temp['prob_home'] > rand_vals).loc[not_played_yet].astype(int)
    schedule_temp.loc[not_played_yet,'away_win'] = 1 - schedule_temp['home_win'].loc[not_played_yet]

    #Adding wins / losses to standings
    standings_temp['W'] = schedule_temp.groupby('away team')['away_win'].apply(lambda x: sum(x.astype(int)))
    standings_temp['L'] = schedule_temp.groupby('away team')['home_win'].apply(lambda x: sum(x.astype(int)))

    standings_temp['W'] = standings_temp['W'] + schedule_temp.groupby('home team')['home_win'].apply(lambda x: sum(x.astype(int)))
    standings_temp['L'] = standings_temp['L'] + schedule_temp.groupby('home team')['away_win'].apply(lambda x: sum(x.astype(int)))
    # print(sum(standings_temp['W']))
    #calculating win percentage based off wins and ties
    standings_temp['win_percent'] = standings_temp['W'] /num_mlb_games * 100

    #adding epsilon to break ties randomly
    standings_temp['win_percent'] = standings_temp['win_percent'] + np.random.random(num_teams) * 0.001

    #calculating division rank
    standings_temp['divisionRank'] = standings_temp.groupby(['League', 'Conference'])[['win_percent']].rank(ascending = False)

    #indicator measuring who won division
    standings_temp['wonDivision'] = standings_temp['divisionRank'] == 1

    return standings_temp['wonDivision'].astype(int)

def plot_binned_stats(schedule, bin_num = 5):
    
    '''function to get standings and schedule_temp based off of SRS
    
    Args:
        schedule: dataframe
            schedule_temp of games with these columns: Week, playoff_game, away team, home team, and home margin
        bin_num: int
            number of bins
    Return:
        shows a plot of binned stats
    '''
    
    #making copy of value
    schedule_temp = schedule.copy()
    
    #removing games that have results
    schedule_temp = schedule_temp.loc[pd.isna(schedule_temp['home margin'])]
        
    #keeeping necessary columns
    schedule_temp  = schedule_temp[['home_win', 'away_win', 'prob_home']]
    
    #removing games that have not occured yet
    schedule_temp = schedule_temp.loc[((schedule_temp['home_win'] == 1) | (schedule_temp['away_win'] == 1))]
    
    #making sure games exist
    if len(schedule_temp) != 0:
        
        #getting groups for probability and predicted wins
        schedule_temp['predicted_prob_group'] =  pd.cut(schedule_temp['prob_home'], bins = bin_num)
        schedule_temp_plot =  schedule_temp.groupby('predicted_prob_group')['home_win'].apply(lambda x: np.mean(x))
        
        #series to df
        schedule_temp_plot = schedule_temp_plot.reset_index()
    
        #standard deviation
        schedule_temp_plot['std'] = 2 * schedule_temp.groupby('predicted_prob_group')['prob_home'].sem().values
    
        #getting number from categorical group
        schedule_temp_plot['predicted_prob_group'] = schedule_temp_plot.predicted_prob_group.map(attrgetter('right')).astype(float)

    
        #plotting results
        plt.title('Observed Win Probabilities vs Predicted Win Probabilities')
        plt.errorbar(schedule_temp_plot['predicted_prob_group'], schedule_temp_plot['home_win'],
                 yerr= schedule_temp_plot['std'],fmt=".", capsize = 5)
        plt.yticks(np.arange(0,1.1,0.1), ['{:,.0%}'.format(x) for x in np.arange(0,1.1,0.1)]);
        plt.xticks(np.arange(0,1.1,0.1), ['{:,.0%}'.format(x) for x in np.arange(0,1.1,0.1)]);
        plt.plot([0,1],[0,1], 'r')
        
        plt.show()
