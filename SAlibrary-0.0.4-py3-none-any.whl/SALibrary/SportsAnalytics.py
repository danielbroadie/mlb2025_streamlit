#Tom Bliss version 11/2

#New functions:
# Average -works same as BA.Average
# Stddev - works same as BA.Stddev

#changes
# Graph_Binned_stats_with_prediction - can now have multiple lines
# model_test - fixed issue with p-value

# Changes - 20240706 - Phil Goddard
# - converted print("Error ...") constructs to raise Exception("...")
# - removed printing of data from within functions

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.discrete.discrete_model as discrete_model
import matplotlib.pyplot as plt
from scipy import stats
from scipy.optimize import linprog
from statsmodels.stats.weightstats import DescrStatsW

# In[ ]:

def LogisticRegTrain(X,Y,Const=True,weight = None,Missing = 'delete'):
    """Train a Logistic Regression Model

    Args:
        X: pandas DataFrame, or numpy ndarray
            independent variables, each column represents one variable
            X and Y has the same index
        Y: pandas DataFrame, or numpy ndarray
            dependent variable, one column
        Const: boolean, default True
            Indicator for the constant term (intercept) in the fit.
        weight: 1d numpy array,
            weight of each column
        Missing: 'delete','nearest','mean','median',constant number
            the method to handle the missing value

    Returns:
        A logistic regression model
    """
    # missing values
    dataSet = pd.concat([X,Y],axis=1)

    if Missing == 'delete':
        dataSet = dataSet.dropna()
    elif Missing == 'nearest':
        dataSet = dataSet.fillna(method='ffill')
        dataSet = dataSet.fillna(method='bfill')
    elif Missing == 'mean':
        values = dict(dataSet.mean())
        dataSet = dataSet.fillna(value=values)
    elif Missing == 'median':
        values = dict(dataSet.median())
        dataSet = dataSet.fillna(value=values)
    else:
        try:
            const = float(Missing)
        except:
            raise Exception("Input Missing has been mis-specified. Must be one of 'delete','nearest','mean','median',or a constant number")
            
        dataSet = dataSet.fillna(const)
        
    X = dataSet[dataSet.columns.values[:-1]]
    Y = dataSet[dataSet.columns.values[-1]]

    # row weight
    if weight is not None:
        X = pd.DataFrame(data=X.values*weight,columns=X.columns.values,index=X.index)

    # model w/t or w/o constant
    if Const is True:
        X = sm.add_constant(X)
        columnsName=['const']+['x%s' % n for n in range(1,X.shape[1])]
    else:
        columnsName=['x%s' % n for n in range(1,X.shape[1])]

    # train the model
    model = discrete_model.Logit(Y, X)
    result = model.fit()


    try:
        mdlCoeff = pd.DataFrame(data=dict(result.params), index=['Coefficients'])
        mdlSE = pd.DataFrame(data=dict(result.bse), index=['Std error'])
        mdlPvalue = pd.DataFrame(data=dict(result.pvalues), index=['p-value'])

    except:
        mdlCoeff = pd.DataFrame(data=result.params, index=columnsName, columns=['Coefficients']).T
        mdlSE = pd.DataFrame(data=result.bse, index=columnsName, columns=['Std error']).T
        mdlPvalue = pd.DataFrame(data=result.pvalues, index=columnsName, columns=['p-value']).T


    SummaryTable = pd.concat((mdlCoeff,mdlSE,mdlPvalue))
    SummaryTable.loc['Log-likelihood',SummaryTable.columns.values[0]] = result.llf
    SummaryTable.loc['Number valid obs',SummaryTable.columns.values[0]] = result.df_resid
    SummaryTable.loc['Total obs',SummaryTable.columns.values[0]] = result.nobs

    SummaryTable = SummaryTable.fillna('')

    try:
        SummaryTable.index.name = Y.name
    except:
        pass

    result.SummaryTable = SummaryTable

    return result


# In[ ]:


def LogisticRegPredict(model,X):
    """Make prediction based on the trained logistic regression model
    make sure input X is of the same format as training X data for the model

    Args:
        model: statsmodels.discrete.discrete_model.BinaryResultsWrapper
            a logistic regression model
        X: pandas DataFrame, or numpy ndarray
            independent variables, each column represents one variable

    Returns:
        Array of predictions
    """
    if 'const' in model.SummaryTable.columns.values:
        print('adding constant')
        X = sm.add_constant(X, has_constant='add')
    print(X)
    prediction = model.predict(X)

    data = pd.DataFrame(data=X,columns=list(model.SummaryTable.columns.values))
    if 'const' in model.SummaryTable.columns.values:
        data = data.drop(['const'],axis=1)
    data['prediction'] = prediction
    #data.style.format({'prediction':"{:.2%}"})

    result = data
    
    return result 


# In[ ]:
def LinearRegTrain(X,Y,Const=True,weight = None,Missing = 'delete'):
    """Train a Linear Regression Model

    Args:
        X: pandas DataFrame, or numpy ndarray
            independent variables, each column represents one variable
            X and Y has the same index
        Y: pandas DataFrame, or numpy ndarray
            dependent variable, one column
        Const: boolean, default True
            Indicator for the constant term (intercept) in the fit.
        weight: 1d numpy array,
            weight of each column
        Missing: 'delete','nearest','mean','median',constant number
            the method to handle the missing value

    Returns:
        A linear regression model
    """
    # missing values
    dataSet = pd.concat([X,Y],axis=1)

    if Missing == 'delete':
        dataSet = dataSet.dropna()
    elif Missing == 'nearest':
        dataSet = dataSet.fillna(method='ffill')
        dataSet = dataSet.fillna(method='bfill')
    elif Missing == 'mean':
        values = dict(dataSet.mean())
        dataSet = dataSet.fillna(value=values)
    elif Missing == 'median':
        values = dict(dataSet.median())
        dataSet = dataSet.fillna(value=values)
    else:
        try:
            const = float(Missing)
        except:
            raise Exception("Input Missing has been mis-specified. Must be one of 'delete','nearest','mean','median',or a constant number")
            
        dataSet = dataSet.fillna(const)
        
    X = dataSet[dataSet.columns.values[:-1]]
    Y = dataSet[dataSet.columns.values[-1]]

    # row weight
  #  if weight is not None:
  #      X = pd.DataFrame(data=X.values*weight,columns=X.columns.values,index=X.index)

    # model w/t or w/o constant
    if Const is True:
        X = sm.add_constant(X)
        columnsName=['const']+['x%s' % n for n in range(1,X.shape[1])]
    else:
        columnsName=['x%s' % n for n in range(1,X.shape[1])]

    # train the model
    if weight is not None:
        model = sm.WLS(Y, X, weights=weight)
        result = model.fit()
    if weight is None:
        model = sm.OLS(Y, X)
        result = model.fit()

    try:
        mdlCoeff = pd.DataFrame(data=dict(result.params), index=['Coefficients'])
        mdlSE = pd.DataFrame(data=dict(result.bse), index=['Std error'])
        mdlPvalue = pd.DataFrame(data=dict(result.pvalues), index=['p-value'])

    except:
        mdlCoeff = pd.DataFrame(data=result.params, index=columnsName, columns=['Coefficients']).T
        mdlSE = pd.DataFrame(data=result.bse, index=columnsName, columns=['Std error']).T
        mdlPvalue = pd.DataFrame(data=result.pvalues, index=columnsName, columns=['p-value']).T


    SummaryTable = pd.concat((mdlCoeff,mdlSE,mdlPvalue))
    SummaryTable.loc['Log-likelihood',SummaryTable.columns.values[0]] = result.llf
    SummaryTable.loc['Number valid obs',SummaryTable.columns.values[0]] = result.df_resid
    SummaryTable.loc['Total obs',SummaryTable.columns.values[0]] = result.nobs

    SummaryTable = SummaryTable.fillna('')

    try:
        SummaryTable.index.name = Y.name
    except:
        pass

    result.SummaryTable = SummaryTable

    return result

def LinearRegPredict(model,X):
    """Make prediction based on the trained linear regression model
    make sure input X is of the same format as training X data for the model

    Args:
        model: statsmodels linear regression model
        X: pandas DataFrame, or numpy ndarray
            independent variables, each column represents one variable

    Returns:
        Array of predictions
    """
    if 'const' in model.SummaryTable.columns.values:
        X = sm.add_constant(X)

    prediction = model.predict(X)

    data = pd.DataFrame(data=X,columns=list(model.SummaryTable.columns.values))
    if 'const' in model.SummaryTable.columns.values:
        data = data.drop(['const'],axis=1)
    data['prediction'] = prediction
    #data.style.format({'prediction':"{:.2%}"})

    result = data
    return result


# todo here
def Binned_stats(buckets,col1,col2,includeSE=None,SEMultiplier=None,includeSD=None,SD=None):
    """ Create a summary table of binned stats

    Args:
        buckets: list of float
            a list of buckets boundaries
        col1: pandas DataFrame, or numpy ndarray
            reference column
        col2: pandas DataFrame, or numpy ndarray
            data value column
        includeSE: boolean
            indicator of whether to include standard error in the stats
        SEMultiplier: float
            Standard error multiplier
        includeSD: boolean
            indicator of whether to include standard deviation in the stats
        SD: float
            Standard deviation array

    Returns:
        table of binned stats
        
    """
    dataDic = {}

    idxLable = []
    count = []
    avg1 = []
    avg2 = []
    stderr2 = []
    stdd2 = []
    for i in range(len(buckets)-1):
        idxLable.append('[%s,%s)' % (buckets[i],buckets[i+1]))
        count.append(col1[(col1>=buckets[i])&(col1<buckets[i+1])].count())
        avg1.append(col1[(col1>=buckets[i])&(col1<buckets[i+1])].mean())
        avg2.append(col2[(col1>=buckets[i])&(col1<buckets[i+1])].mean())
        stderr2.append(col2[(col1>=buckets[i])&(col1<buckets[i+1])].sem()*2)

    idxLable[-1] = ('[%s,%s]' % (buckets[i],buckets[i+1]))

    dataDic['Bins'] = idxLable
    dataDic['Count'] = count
    dataDic['Avg '+col1.name] = avg1
    dataDic['Avg '+col2.name] = avg2
    dataDic['Stderr '+col2.name] = stderr2

    orderList = ['Bins','Count','Avg '+col1.name,'Avg '+col2.name,'Stderr '+col2.name]
    SummaryTable = pd.DataFrame(data=dataDic)[orderList]
    return SummaryTable



# In[ ]:


def Graph_Binned_stats(binned_stats):
    """Draw the graph

    Args:
        binned_stats: pandas DataFrame
            output summary table of function Binned_stats()
            
    """
    
    colName = list(binned_stats.columns.values)
    fig = plt.figure(figsize=(10,8))
    plt.errorbar(binned_stats[colName[2]], binned_stats[colName[3]], yerr=binned_stats[colName[4]],fmt=".",capsize=5)
    plt.show()
    return fig


#Tom added linestyle as option and allowing multiple lines to be plotted
def Graph_Binned_stats_with_prediction(binned_stats,lineX,lineY,linestyle,lineX2 = None,lineY2 = None,linestyle2 = None):
    """Draw the graph

    Args:
        binned_stats: pandas DataFrame
            output summary table of function Binned_stats()
        line_x: x input to graph for predictions
        line_y: y output of prediciton
        linestyle: style of line
        line_x2: second x input to graph for predictions
        line_y2: second y output of prediciton
        linestyle2: second style of line
    """
    #fig = Graph_Binned_stats(binned_stats)
    colName = list(binned_stats.columns.values)
    fig = plt.figure(figsize=(10,8))
    plt.errorbar(binned_stats[colName[2]], binned_stats[colName[3]], yerr=binned_stats[colName[4]],fmt=".",capsize=5)

    if lineX2 != None:
        plt.plot(lineX,lineY,linestyle,lineX2,lineY2,linestyle2)

    else:
        plt.plot(lineX,lineY,linestyle)

    plt.xlabel('distance')
    plt.ylabel('make')

    return fig


# In[ ]:


def Bayes_normal(mean,stdev,Nob,sample_mean,sample_stdev):
    """Print the table of binned stats

    Args:
        mean: float
            mean of the population
        stdev: float
            standard deviation of population
        Nob: int
            number of observations
        sample_mean: float
            mean of the sample
        sample_stdev: float
            standard deviation of sample

    Returns:
        table of binned stats
    """

    post_m = (mean/stdev**2 + Nob*sample_mean/sample_stdev**2) / (1/stdev**2 + Nob/sample_stdev**2)
    post_sd = np.sqrt( 1 / (1/stdev**2 + Nob/sample_stdev**2) )

    return post_m,post_sd


# In[ ]:


def RMSE(errorValues = None,PredictionValue = None, Truth = None):
    """Calculate the RMSE of each model

    Args:
        errorValues: pandas Dataframe
            matrix of errors from different model, each column represents 1 series of error
        PredictionValue: pandas Dataframe or Series
            matrix of predictions from different model, each column represents 1 series of prediction
        Truth: pandas Series
            array of truth, 1 column

    Returns:
        table of RMSE
    """
    if errorValues is not None:
        if PredictionValue is None and Truth is None:
            rmseArray = np.sqrt(np.mean(errorValues**2,axis=0))
        else:
            raise Exception('Only define errorValues, or only define PredictionValue and Truth')
            
    else:
        if PredictionValue is not None and Truth is not None:
            if type(PredictionValue) is pd.DataFrame:
                rmseArray = np.sqrt(np.mean((PredictionValue.transpose()-Truth)**2,axis=1))
            else:
                rmseArray = np.sqrt(np.mean((PredictionValue.transpose()-Truth)**2))
        else:
            raise Exception('Only define errorValues, or only define PredictionValue and Truth')
            

    return rmseArray


# In[ ]:


def model_test(errorValues = None, PredictionValue = None, Truth = None):
    """calculate the RMSE of each model and p-value matrix and result of pairwise comparison among models

    Args:
        PredictionValue: pandas Dataframe
            matrix of predictions from different model, each column represents 1 series of prediction
        Truth: pandas Dataframe
            array of truth, 1 column

    Returns:
        table of RMSE and p-value matrix of each model
    """
    # rmseArray = np.sqrt(np.mean((PredictionValue.transpose()-Truth)**2,axis=1))
    # print(rmseArray)

    # calculate the squared error, and use it in the following sentences


    # blabla
    if errorValues is not None:
        if PredictionValue is None and Truth is None:
            rmseArray = np.sqrt(np.mean(errorValues**2,axis=0))
            sqErr = errorValues.values**2
            names = list(errorValues.columns.values)
        else:
            raise Exception('Only define errorValues, or only define PredictionValue and Truth')

    else:
        if PredictionValue is not None and Truth is not None:
            rmseArray = np.sqrt(np.mean((PredictionValue.values-Truth.values)**2,axis=0))
            sqErr = (PredictionValue.values-Truth.values)**2
            names = list(PredictionValue.columns.values)
        else:
            raise Exception('Only define errorValues, or only define PredictionValue and Truth')
            return None

    pvalueMatrix = np.empty(shape = (sqErr.shape[1],sqErr.shape[1]))
    pvalueMatrix[:] = np.nan

    for eachCol in range(sqErr.shape[1]):
        for eachCol2 in range(eachCol+1,sqErr.shape[1]):
            tmp_t,tmp_p = stats.ttest_rel(sqErr[:,eachCol], sqErr[:,eachCol2])
            pvalueMatrix[eachCol,eachCol2] = 1 - tmp_p/2 #TOM BLISS ADDITION
            pvalueMatrix[eachCol2,eachCol] = tmp_p/2 #TOM BLISS ADDITION

    # Create a viewable table
    if isinstance(rmseArray, np.ndarray):
        SummaryTable = pd.DataFrame(data=pd.DataFrame(np.concatenate([rmseArray[:,None],pvalueMatrix],axis=1).T))
    else:
        rmseArray = rmseArray.to_numpy().reshape(rmseArray.size,1)  # Must be a numpy array as a column
        SummaryTable = pd.DataFrame(data=pd.DataFrame(np.concatenate([rmseArray,pvalueMatrix],axis=1).T))
        
    SummaryTable.columns = names
    SummaryTable.index = ["RMSE"]+names

    SummaryTable = SummaryTable.fillna('')
    
    return SummaryTable

#Tom's Additions:
def Average(Array1, row_weight):
    """calculate a weighted mean

    Args:
        Array1: Array of numbers.
        row_weight: weight of each number in average

    Returns:
        A weighted mean
    """

    return np.average(Array1, weights = row_weight)


def Stddev(Array1, row_weight):
    """calculate a weighted standard deviation

    Args:
        Array1: Array of numbers.
        row_weight: weight of each number in average

    Returns:
        A weighted standard deviaiton
    """

    return np.sqrt(np.cov(Array1, aweights=row_weight))

#############################################################################
# Function to calculate model scores, and statistics related to comparing
# model perfromance
#############################################################################
def model_score(df_truth, df_mdl,method = "brier"):
    """

    Parameters
    ----------
    df_truth : dataframe
        truth values to compare the model predictions against.
    df_mdl : may be either of the following,
        - a dataframe of model predictions (treated as a single model)
        - a list of dataframes with each containing model predictions (treated
            as multiple models)
        - a 2 element list where the first element is an integer and the second
            is a single dataframe (each consecutive n columns are treated
            as separate models)
    method : str
        Must be "brier" (default) or "logloss".

    Returns
    -------
    scores: dataframe
        A score for each row of the dataframe(s).
    stats: dataframe
        mean score for each model, and p-values for comparing the models

    """
    
    if not isinstance(method,str):
        raise Exception("The method must be a str")
    elif not (method.lower() in ["brier","logloss"]):
        raise Exception("The method must be 'brier' or 'logloss'")
        
    if not isinstance(df_truth,pd.DataFrame):
        raise Exception("df_truth must be a pandas dataframe")
    elif df_truth.shape[1] != 1:
        raise Exception("df_truth must contain only 1 column")
        
    # Code assumes the mdl is a list of dataframes, even if it is only 1 dataframe
    if not isinstance(df_mdl,list):
        df_mdl = [df_mdl]
    
    # Check is a list containing the number of models and as single dataframe 
    # has been input
    if (len(df_mdl) == 2) and isinstance(df_mdl[0],int):
        
        if not isinstance(df_mdl[1],pd.DataFrame):
            raise Exception("Expecting second element of list to be a pandas dataframe.")
        
        n_models = df_mdl[0]
        n_cols = len(df_mdl[1].columns)
        n_cols_in_each_model = int(n_cols/n_models)
        
        if ((n_cols/n_models) != n_cols_in_each_model):
            raise Exception(f"The specified number of models ({n_models}) is inconsistent with a dataframe having {n_cols} columns")

        # Split the dataframe
        df_mdl = [df_mdl[1].iloc[:,(n_cols_in_each_model*idx):(n_cols_in_each_model*(idx+1))] for idx in range(0,n_models)]
    
    if not all([isinstance(mdl,pd.DataFrame) for mdl in df_mdl]):
        raise Exception("df_mdl must be a pandas dataframe or a list of dataframes")
    elif not all([mdl.shape[0]==df_truth.shape[0] for mdl in df_mdl]):
        raise Exception("df_truth and df_mdl must have the same number of rows")
    
    num_cols = [len(mdl.columns) for mdl in df_mdl]
    if not all([num_cols[0] == cols for cols in num_cols]):
        raise Exception("All models must have the same number of rows")
        
    # The values in df_truth are assumed to be 1 based indexing, so a -1 is 
    # needed on the following line to account for python using 0 based indexing
    max_truth = df_truth.max()
    min_truth = df_truth.min()
    if (max_truth > num_cols[0]).bool():
        raise Exception("Truth values cannot be greater than the number of model columns")
    if (min_truth < 1).bool():
        raise Exception("Truth values must be positive")
        
    # Calculate a score for each row in each model
    scores = []
    
    for this_mdl in df_mdl:
        
        # Get values in column corresponding to truth value
        col_num = [(x[0]-1) for x in df_truth.values.tolist()] # Does this really need to be a list?
        n_rows = len(this_mdl)
        col_data = this_mdl.to_numpy()[range(n_rows),col_num]
        
        # Calculate the score for each prediction
        if method.lower() == "brier":
            
            partA = ((1-col_data)**2)
            partB = (this_mdl**2).sum(axis=1).to_numpy()
            partC = (col_data**2)
            score =  partA + partB - partC
            
        elif method.lower() == "logloss":
            
            score = np.log(1/col_data)
            
        scores.append(score)

    # Convert the scores to a dataframe
    col_names = ["Model " + str(i+1) for i in range(0,len(scores))]
    scores = pd.DataFrame(scores).transpose()
    scores.columns = col_names
    
    # If multiple models have been input then calculate p-values for comparing
    # each pair of performances
    n_models = len(df_mdl)
    
    if n_models < 2:
        
        p_values = [np.nan]  # Must be in a list to later convert to a dataframe
        
    else:
        
        p_values = np.full([n_models,n_models],np.nan)
        
        for idx in range(0,n_models):
            for jdx in range(idx+1,n_models):
                
                score_diff = scores.iloc[:,jdx] - scores.iloc[:,idx]
                avg_score_diff = (score_diff).mean()
                var_score_diff = ((score_diff - avg_score_diff)**2).sum() /n_rows
                stderr_score_diff = np.sqrt(var_score_diff / (n_rows-1))
                tstat = avg_score_diff / stderr_score_diff
                p_values[idx,jdx] = stats.t.cdf(tstat, n_rows - 1)
                p_values[jdx,idx] = 1 - p_values[idx,jdx]
        
    # Convert p_values as a dataframe
    p_values = pd.DataFrame(p_values)
    p_values.columns = col_names
    p_values.index = col_names
    
    # Consolidate the stats into a dataframe
    avg_score = scores.mean().to_frame().transpose()
    avg_score.index = ["Avg Score"]
    score_stats = pd.concat([avg_score,p_values],axis=0)
    score_stats = score_stats.fillna("")
    
    return scores, score_stats

#############################################################################
# Function to generate stats based on a grouping variable
#############################################################################
def group_stats(df,grp_col_names,stats_col_names,wt_col_name = None):
    """

    Parameters
    ----------
    df : dataframe
        may include more columns than are being grouped, but those are ignored
    grp_col_names : list
        names of columns that define the grouping variables.
    stats_col_names : list
        names of columns that stats are to be calculated for.  Columns must contain
        numeric data.  Cannot include any of the columns specified in grp_col_names.
    wt_col_name : str
        name of a weighting column.  If not specified then all rows are equally
        weighted.
        Must be numeric or boolean.  Values of 0 imply that the corresponding row
        should be removed before the stats are calculated.

    Returns
    -------
    grp_stats: dataframe
        calculated statistics for each group

    """

    # Create a copy of the dataframe so that changes do not affect the original one
    if wt_col_name is None:
        df = df[grp_col_names + stats_col_names].copy(deep=True)
        df["wt"] = 1
    else:
        df = df[grp_col_names + stats_col_names + [wt_col_name]].copy(deep=True)
        df = df.rename(columns={wt_col_name: "wt"})
        
    # Remove rows where the wt is zero
    df = df.loc[df["wt"].astype(bool),:]

    # Append columns for the weighted values
    wt_value_col_names = []
    for this_col in stats_col_names:
        wt_value_col_names.append("wt_" + this_col)
        df[wt_value_col_names[-1]] = df[this_col] * df["wt"]
        
    # Calculate some stats for the weights and weighted values
    df["wt2"] = df["wt"]**2

    df_grp = df.groupby(grp_col_names)
    grp_wts_sum = df_grp.size().to_frame(name='N')
    grp_wts_sum = (grp_wts_sum
        .join(df_grp[["wt", "wt2"] + wt_value_col_names].sum())
        .reset_index()
    )

    # Calculate the weighted mean
    wt_avg = grp_wts_sum[grp_col_names + ["wt"]].join(grp_wts_sum[wt_value_col_names].div(grp_wts_sum["wt"],axis=0))
    wt_avg = wt_avg.rename(columns = {"wt": "Count"})
    wt_avg.columns = [s.replace("wt_","mean_") for s in wt_avg.columns.to_list()]
    
    # Append columns for the weighted error squared values
    df = pd.merge(df,wt_avg,on=grp_col_names)
    wt_err2_col_names = []
    for this_col in stats_col_names:
        wt_err2_col_names.append("wt_err2_" + this_col)
        df[wt_err2_col_names[-1]] = (df[this_col] - df["mean_"+this_col])**2 * df["wt"]
    
    # calculate stats for weighted errors
    df_grp = df.groupby(grp_col_names)
    grp_err_sum = df_grp[wt_err2_col_names].sum().reset_index()  
    grp_wts_sum = pd.merge(grp_wts_sum,grp_err_sum,on=grp_col_names)
    
    # Calculate the weighted std
    num = grp_wts_sum[wt_err2_col_names]
    den = (grp_wts_sum["N"] - 1).div(grp_wts_sum["N"]) * grp_wts_sum["wt"] 
    wt_var = num.div(den,axis=0)
    wt_std = wt_var.apply(np.sqrt)
    wt_std.columns = [s.replace("wt_err2_","std_") for s in wt_std.columns.to_list()]
    
    # Create the final stats table
    wt_stats = pd.concat([wt_avg,wt_std],axis=1)

    return wt_stats

#############################################################################
# Function to generate summary stats for a dataset
#############################################################################
def summary_stats(df,wt):
    """

    Parameters
    ----------
    df : dataframe
        Stats will be returned for all columns
    wt : Series
        Must be numeric or boolean.  Values of 0 imply that the corresponding row
        should be removed before the stats are calculated.

    Returns
    -------
    summary_stats: dataframe
        calculated statistics for each column of the input

    """
    
    # Remove rows where the wt is zero
    good_row = wt.astype(bool) & ~pd.isna(wt)
    df = df.loc[good_row,:].copy(deep=True)
    wt = wt[good_row].copy(deep=True)

    # Unfortnately DescrStatsW from statsmodels seems not to ignore missing values,
    # and since each column may have missing values in different locations we need
    # to loop over each column to calculate their stats individually
    
    summary_stats_list = []
    for this_col in df.columns:

        # get index of where this column has good data
        good_row = ~pd.isna(df[this_col])

        df_this_col = df.loc[good_row,this_col]
        wt_this_col = wt[good_row]

        # Calculate the primary statistics
        wdf = DescrStatsW(df_this_col, weights=wt_this_col, ddof=1) 
        
        summary_stats = pd.DataFrame(df_this_col.count(),columns=[this_col],index=["Count"])
        
        mean_and_std = pd.DataFrame(np.vstack((wdf.mean,wdf.std)))
        mean_and_std.columns = summary_stats.columns
        
        summary_stats = pd.concat([summary_stats,mean_and_std],axis=0)
        summary_stats.index = ["Count","Mean","Std"]

        # Calculate skewness and Kurtosis
        wsum = (wt_this_col).sum()
        w2sum = (wt_this_col**2).sum()
        w3sum = (wt_this_col**3).sum()
        stdev = wdf.std
        err = (df_this_col - wdf.mean)
        e3sum = ((err**3)*wt_this_col).sum()
        e4sum = ((err**4)*wt_this_col).sum()
        denom = (wsum*wsum*wsum - 3*wsum*w2sum + 2*w3sum)
        if (denom > 1e-6):
            skew = e3sum * wsum*wsum / denom / (stdev*stdev*stdev)
            kurto = e4sum / wsum / (stdev*stdev*stdev*stdev) - 3.0
        else:
            skew = np.nan
            kurto = np.nan
        
        s_and_k = pd.DataFrame(np.vstack((skew,kurto)))
        s_and_k.columns = summary_stats.columns
        s_and_k.index = ["Skewness","Kurtosis"]
        
        summary_stats = pd.concat([summary_stats,s_and_k],axis=0)
        
        
        # Calculate the quantiles
        qtiles = wdf.quantile([0,0.01,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.99,1]).to_frame()
        qtiles.columns = summary_stats.columns
        qtiles.index.name = None
        qtiles.index = ["Min","1% percentile","5% percentile","10% percentile","25% percentile",
                         "50% percentile","75% percentile","90% percentile","95% percentile","99% percentile","Max"]
        
        summary_stats = pd.concat([summary_stats,qtiles],axis=0)

        summary_stats_list.append(summary_stats)

    return pd.concat(summary_stats_list,axis=1)

#############################################################################
# Function to generate summary stats for streaks
#############################################################################
def streak_stats(df):
    """

    Parameters
    ----------
    df : dataframe
        One or more columns of trials.

    Returns
    -------
    streak_stats: dataframe
        calculated summary statistics for each column of the input

    """

    # Each column could potentially have different labels for the trial outcomes, so
    # loop over and process each column separately
    streak_stats = []
    
    for data_name in df.columns:
        
        data = df[[data_name]]

        # Calculate stats for the complete data set
        general_stats = pd.DataFrame([data.mean()[0],len(data)],columns=[data_name],index=["Average","N trials"])

        # Calculate some meta data about the streaks
        data["start_of_streak"] = data.ne(data.shift())
        data["streak_id"] = data.start_of_streak.cumsum()
        data["streak_counter"] = data.groupby("streak_id").cumcount() + 1

        # Calculate the length of max streak for each outcome
        max_streak = data[[data_name,"streak_counter"]].groupby(data_name).max()
        max_streak.index.name=None
        max_streak.columns = [data_name]
        max_streak.index = ["Longest streak of {}'s".format(x,) for x in max_streak.index.tolist()]

        # Calculate the longest streak, irrespective of outcome
        longest_streak = pd.DataFrame(max_streak.max()[0],columns=[data_name],index=["Max streak"])

        # Calculate the number of streaks
        streak_start = data.loc[data.start_of_streak,:]
        nstreaks = streak_start[[data_name,"streak_id"]].groupby(data_name).count()
        nstreaks.index.name=None
        nstreaks.columns = [data_name]
        nstreaks.index = ["Runs of {}'s".format(x,) for x in nstreaks.index.tolist()]  

        # Calculate the total number of streaks
        total_streaks = pd.DataFrame(len(streak_start),columns=[data_name],index=["Total streaks"])

        # Package everything into one dataframe
        df_stats = pd.concat([general_stats,max_streak,longest_streak,nstreaks,total_streaks],axis=0)
        
        streak_stats.append(df_stats)
        
    # Create a unified table to output
    df_streak_stats =  pd.concat(streak_stats,axis=1,ignore_index=True)
    df_streak_stats.columns = df.columns
    
    return df_streak_stats

def explode_and_align(labels,model):
    """

    Parameters
    ----------
    labels : pandas dataframe or series
        If a DataFrame then must have only one column
    model : pandas dataframe

    Returns
    -------
    exploded_array: dataframe
        calculated summary statistics for each column of the input


    Convert labels (a vector) to have the same size as models (a matrix),
    then transform to a dataframe where each row has 3 values:
    column number (of the matrix,) label, and correspondng value (from the matrix)

    >>> labels = pd.Series([1,2,3],name="targets")
    >>> models = pd.DataFrame([[1,2],[3,4],[5,6]])
    >>> explode_and_align(labels,models)


    """
    
    if (not isinstance(labels,pd.DataFrame)) and (not isinstance(labels,pd.Series)):
        raise Exception("First input must be a pandas DataFrame or Series")
        
    if (not isinstance(model,pd.DataFrame)):
        raise Exception("Second input must be a pandas DataFrame")

    if len(labels) != len(model):
        raise Exception("The number of elements in the first input must match the" \
                        " number of rows in the second input")
    
    # Get/define name for the columns
    name_col1 = "column"
    
    name_col2 = "labels"
    if isinstance(labels,pd.DataFrame):
        
        if len(labels.columns) > 1:
            raise Exception("First input must contain only 1 column")
            
        name_col2 = labels.columns.to_list()[0]
        
    elif isinstance(labels,pd.Series):
        
        name_col2 = labels.name
        
    name_col3 = "model"
    
    # Perform the explosion
    n_cols = len(model.columns)
    n_rows = len(model)
    exploded_array = pd.concat([
        pd.DataFrame(np.arange(1,n_cols+1).reshape((1,-1)).repeat(n_rows,axis=0).flatten(),columns=[name_col1]),
        pd.DataFrame(labels.values.repeat(n_cols).reshape((-1,1)),columns=[name_col2]),
        pd.DataFrame(model.values.flatten().reshape((-1,1)),columns=[name_col3])],
        axis=1)
    
    return exploded_array

