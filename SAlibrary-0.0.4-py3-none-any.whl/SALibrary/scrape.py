
# coding: utf-8

# In[ ]:


from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import re
import datetime
import itertools

def scrape_mlb(yearSeasonStart):
    """
        Scrape MLB
    """
    url_template = "https://www.baseball-reference.com/leagues/majors/{year}-schedule.shtml"
    #getting HTML for standings
    url = url_template.format(year=yearSeasonStart)
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')
    games = soup.find('div', {'class', 'section_content'}).find_all('div')

    def append_game(d):
        date = d.find('h3').getText()
        date = datetime.date.today() if "Today" in date else datetime.datetime.strptime(date, '%A, %B %d, %Y')
        date_list = [date.strftime('%m/%d/%Y'), date.strftime('%B')]
        return list(map(lambda x: (x,date_list), d.find_all('p', {'class': 'game'})))
    dates_games = list(map( append_game , games))
    dates_games = list(itertools.chain(*dates_games))

    def find_teams_and_scores(date_games):

        game_result = list(map(BeautifulSoup.getText, date_games[0].find_all('a')[:2]))
        pattern = '\((.*)\).*\((.*)\)'
        scores_regex = re.search(pattern, date_games[0].getText(), re.S)
        game_result += [np.nan,np.nan] if scores_regex is None else list(map(int,scores_regex.groups()))
        return date_games[1] + game_result

    results = pd.DataFrame(map(find_teams_and_scores, dates_games), columns = ['date', 'month', 'away team','home team', 'away score', 'home score'])
    results = results.reindex(columns=['date', 'month', 'home team', 'away team','home score','away score'])
    results.replace("Arizona D'Backs" , 'Arizona Diamondbacks', inplace = True)
    results['home margin'] = results['home score'] - results['away score']

    url_template = "https://www.baseball-reference.com/leagues/majors/{year}-standings.shtml"
    url = url_template.format(year=yearSeasonStart)
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')

    league_standings = soup.find_all('div', {'id':'all_standings'})
    leagues = ['AL', 'NL']
    conferences = ['East', 'Central', 'West']
    standings = []
    headers = []
    for l_standings, l in zip(league_standings, leagues):
        for conf_standings, c in zip(l_standings.find_all('div', id=re.compile('all_standings_.')), conferences):
            headers = list(map(BeautifulSoup.getText, conf_standings.find('thead').find_all('th')))
            for team in conf_standings.find('tbody').find_all('tr'):
                standing = [l,c]+list(map(BeautifulSoup.getText, team.find_all(['th','td'])))
                standings.append(standing)
    headers = ['League', 'Conference'] + headers
    standings = pd.DataFrame(standings, columns = headers)
    standings[['W','L']] = standings[['W','L']].astype('int')
    standings['Tm'] = standings['Tm'].apply(lambda x: x[2:] if x[1]=='-' else x)
    standings.set_index('Tm', inplace = True)
    standings.sort_index(inplace=True)
    return results, standings

def scrape_nfl(yearSeasonStart):
    '''function to scrape website: "https://www.pro-football-reference.com/years/{year}/games.htm"

    Args:
        yearSeasonStart: int
            the start year of a season user want to scrape

    Return:
        pandas dataframe of game schedules and scores
    '''

    #URL to scrape schedule
    url_template = "https://www.pro-football-reference.com/years/{year}/games.htm"

    #loading HTML
    url = url_template.format(year=yearSeasonStart)  # get the url
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')

    #getting column names for schedule dataframe
    column_headers = [th.getText() for th in soup.findAll('thead', limit=1)[0].findAll('th')]
    column_headers[8] = "PtsW"
    column_headers[9] = "PtsL"
    #getting rows
    data_rows = soup.findAll('tbody', limit=1)[0].findAll('tr')[0:]

    #getting data from schedule
    schedule_data = [[td.getText() for td in data_rows[i].findAll(['th','td'])]  for i in range(len(data_rows))]

    #creating dataframe
    schedule = pd.DataFrame(schedule_data, columns=column_headers)

    #removing empty rows / playoff games
    schedule = schedule.loc[((schedule.Week != "Week") &
                           (schedule.Date != "Playoffs"))]


    #adding indicator for playoffs
    schedule['playoff_game'] = ((schedule.Week == "Playoffs") |
                           (schedule.Week == "WildCard") |
                           (schedule.Week == "Division") |
                           (schedule.Week == "ConfChamp") |
                           (schedule.Week == "SuperBowl"))

    #reseting index
    schedule = schedule.reset_index(drop = True)

    #selecting and renaming columns
    schedule = schedule[['Winner/tie', '', 'Loser/tie', 'PtsW', 'PtsL', 'Week', 'playoff_game']]
    schedule.columns = ["Winner/tie", 'at', 'boxscore', 'Loser/tie', 'PtsW', 'PtsL', 'Week', 'playoff_game']

    #making 'at' indicator for home / away team
    schedule['at'] = schedule['at'] == "@"

    #extracting home / away teams
    schedule['away team'] = schedule['Winner/tie'] * schedule['at'] + schedule['Loser/tie'] * (1 -  schedule['at'])
    schedule['home team'] = schedule['Loser/tie'] * schedule['at'] + schedule['Winner/tie'] * (1 -  schedule['at'])
    schedule['away_score'] = schedule['PtsW'] * schedule['at'] + schedule['PtsL'] * (1 -  schedule['at'])
    schedule['home_score'] = schedule['PtsL'] * schedule['at'] + schedule['PtsW'] * (1 -  schedule['at'])


    #Setting to -1 temporarily so it will not be string, later turned to NaN
    schedule.loc[(schedule.PtsW == ''),'PtsW'] = -1
    schedule.loc[(schedule.PtsL == ''),'PtsL'] = -1
    schedule.loc[(schedule.away_score == ''),'away_score'] = -1
    schedule.loc[(schedule.home_score == ''),'home_score'] = -1


    #getting home margin
    schedule['PtsW'] = schedule['PtsW'].astype(int)
    schedule.loc[schedule.PtsW == -1, 'PtsW'] = np.nan

    schedule['PtsL'] = schedule['PtsL'].astype(int)
    schedule.loc[schedule.PtsL == -1, 'PtsL'] = np.nan

    schedule['away_score'] = schedule['away_score'].astype(int)
    schedule.loc[schedule.away_score == -1, 'away_score'] = np.nan

    schedule['home_score'] = schedule['home_score'].astype(int)
    schedule.loc[schedule.home_score == -1, 'home_score'] = np.nan

    schedule['home margin'] = ((schedule['PtsW'] - schedule['PtsL']) *
                                      (-1 * schedule['at'] + (1 -  schedule['at'])))

    #selecting relevant columns
    schedule = schedule[['Week', 'playoff_game', 'away team', 'home team', 'home margin','away_score','home_score']]


    #url standings
    url_template = "https://www.pro-football-reference.com/years/{year}/"

    #getting HTML for standings
    url = url_template.format(year=yearSeasonStart)
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')

    #getting AFC standings
    column_headers_afc = [th.getText() for th in soup.findAll('thead', limit=1)[0].findAll('th')]
    data_rows_afc = soup.findAll('tbody', limit=1)[0].findAll('tr')[0:]
    standings_data_afc = [[td.getText() for td in data_rows_afc[i].findAll(['th','td'])]  for i in range(len(data_rows_afc))]

    #getting NFC standings
    column_headers_nfc = [th.getText() for th in soup.findAll('thead', limit=2)[1].findAll('th')]
    data_rows_nfc = soup.findAll('tbody', limit=2)[1].findAll('tr')[0:]
    standings_data_nfc = [[td.getText() for td in data_rows_nfc[i].findAll(['th','td'])]  for i in range(len(data_rows_nfc))]


    # Turn yearly data into a DataFrame
    standings_afc = pd.DataFrame(standings_data_afc, columns=column_headers_afc)
    standings_nfc = pd.DataFrame(standings_data_nfc, columns=column_headers_nfc, index = np.arange(len(data_rows_afc),
                                                                                             len(data_rows_nfc) +
                                                                                             len(data_rows_afc)))

    #appending standings
    standings = pd.concat([standings_afc,standings_nfc], ignore_index=True)


    #extracting divisions from rows (Will have null in W column if it is a division name)
    divisions = standings.loc[standings['W'].isnull()][["Tm"]]
    divisions.columns = ["division"]

    #remvoing divisions (Will have null in W column if it is a division name)
    standings = standings.loc[(~standings['W'].isnull())]

    #merging divisons back on
    standings = pd.merge(standings,
             divisions, how = 'outer', left_index = True, right_index = True)




    #filling NA info
    standings['division'] = standings['division'].fillna(method = "ffill")


    #dropping NA
    standings = standings.dropna()

    standings = standings.reset_index(drop = True)

    #checking if tie occured in season
    if not ('T' in standings.columns):
        standings['T'] = 0

    standings = standings[['Tm', 'W', 'L', 'T', 'division']]

    standings['Tm'] = standings['Tm'].str.replace('[^A-Za-z0-9- ]', '')

    standings['conference'] = standings['division'].str[0:4]

    standings = standings.set_index('Tm')

    standings['W'] = standings['W'].astype(int)

    standings['L'] = standings['L'].astype(int)

    standings['T'] = standings['T'].astype(int)

    #returning schedule and standings
    return schedule, standings



def scrape_nba(yearSeasonStart):
    '''function to scrape website: "https://www.basketball-reference.com/leagues/NBA_{year}_games-{month}.html"

    Args:
        yearSeasonStart: int
            the start year of a season user want to scrape

    Return:
        pandas dataframe of game schedules and standings
    '''
    
    year = yearSeasonStart + 1

    schedule = pd.DataFrame(columns=['Date', 'month', 'home team','away team','home score','away score', 'playoff_game'])

    url_template = "https://www.basketball-reference.com/leagues/NBA_{year}_games.html"


    #trying to do october, if not, do november
    url_tmp = url_template.format(year = year)



    html_tmp = urlopen(url_tmp)
    soup_tmp = BeautifulSoup(html_tmp, 'html.parser')
    scheduleMonth = [a.getText() for a in soup_tmp.findAll("div",class_ = 'filter')[0].findAll("a")]

    for eachMonth in scheduleMonth:


        url_template = "https://www.basketball-reference.com/leagues/NBA_{year}_games-{month}.html"

        url = url_template.format(year = year, month = eachMonth.lower())

        html = urlopen(url)
        soup = BeautifulSoup(html, 'html.parser')
        column_headers = [th.getText() for th in soup.findAll('thead', limit=1)[0].findAll('th')]
        data_rows = soup.findAll('tbody', limit=1)[0].findAll('tr')[0:]
        game_data = [[td.getText() for td in data_rows[i].findAll(['th','td'])]  for i in range(len(data_rows))]

        month_df = pd.DataFrame(game_data)

        if yearSeasonStart > 2000:

            month_df = month_df.rename(columns={0:"Date", 2:'away team', 3:'away score', 4:'home team', 5:'home score'})

        else:

            month_df = month_df.rename(columns={0:"Date", 1:'away team', 2:'away score', 3:'home team', 4:'home score'})

        #setting every game in may or june as a playoff game
        month_df['playoff_game'] = ((eachMonth.lower() == 'june') | (eachMonth.lower() == 'may'))

        #for april, we must check index
        if((eachMonth.lower() == 'april') & (month_df.Date == "Playoffs").any()):

            #getting index of playoff game
            index_playoff = month_df.loc[month_df.Date == "Playoffs"].index

            month_df.loc[month_df.index > index_playoff[0], "playoff_game"] = 1

            month_df = month_df.loc[month_df.Date != "Playoffs"]


        month_df['playoff_game'] = month_df['playoff_game'].astype(int)

        month_df['month'] = eachMonth

        schedule = pd.concat([schedule,month_df[['Date', 'month', 'home team','away team','home score','away score', 'playoff_game']] ],
                           axis=0, ignore_index=True, sort = False)


    #Setting to -1 temporarily so it will not be string, later turned to NaN
    schedule.loc[((schedule['home score'] == '') | (schedule['home score'] is None)),'home score'] = -1
    schedule.loc[((schedule['away score'] == '') | (schedule['away score'] is None)),'away score'] = -1

    schedule = schedule.fillna(-1)


    #getting home margin
    schedule['home score'] = schedule['home score'].astype(int)
    schedule.loc[schedule['home score'] == -1, 'home score'] = np.nan

    schedule['away score'] = schedule['away score'].astype(int)
    schedule.loc[schedule['away score'] == -1, 'away score'] = np.nan

    schedule['home margin'] = schedule['home score'] - schedule['away score']



    #url standings
    url_template = "https://www.basketball-reference.com/leagues/NBA_{year}_standings.html"

    #getting HTML for standings
    url = url_template.format(year=yearSeasonStart)
    html = urlopen(url)
    soup = BeautifulSoup(html, 'html.parser')

    #getting AFC standings
    column_headers_east = [th.getText() for th in soup.findAll('thead', limit=1)[0].findAll('th')]
    data_rows_east = soup.findAll('tbody', limit=1)[0].findAll('tr')[0:]
    standings_data_east = [[td.getText() for td in data_rows_east[i].findAll(['th','td'])]  for i in range(len(data_rows_east))]

    #getting NFC standings
    column_headers_west = [th.getText() for th in soup.findAll('thead', limit=2)[1].findAll('th')]
    data_rows_west = soup.findAll('tbody', limit=2)[1].findAll('tr')[0:]
    standings_data_west = [[td.getText() for td in data_rows_west[i].findAll(['th','td'])]  for i in range(len(data_rows_west))]



    #making dataframnes for different standings for each conference
    standings_west = pd.DataFrame(standings_data_west, columns=column_headers_west)


    standings_west = standings_west[['Western Conference', 'W', 'L']]

    standings_west.columns = ['Tm', 'W', 'L']

    standings_west['conference'] = 'west'


    standings_east = pd.DataFrame(standings_data_east, columns=column_headers_east)
    standings_east = standings_east[['Eastern Conference', 'W', 'L']]


    standings_east.columns = ['Tm', 'W', 'L']

    standings_east['conference'] = 'east'

    standings = standings_west.append(standings_east, sort = False)

    #removing special characters and numbers
    standings['Tm'] = standings['Tm'].str.replace('[^A-Za-z- ]', '')

    #fixing 76ers name which contains numbers
    standings.loc[standings.Tm == 'Philadelphia ers', 'Tm'] = 'Philadelphia 76ers'

    standings = standings.set_index('Tm')

    standings = standings.dropna()

    standings['W'] = standings['W'].astype(int)

    standings['L'] = standings['L'].astype(int)


    return schedule, standings

def scrape_vegas_wins_nfl(year):
    """

        Scrape vegas wins for NFL season.
        
        Args:
            year: int
            year of the season to scrape.
            
        Return:
            pandas dataframe with vegas win total for each team.

    """

    url_template = "https://www.sportsoddshistory.com/nfl-win/?y={year}&sa=nfl&t=win&o=t"
    url_tmp = url_template.format(year = year)
    html_tmp = urlopen(url_tmp)
    soup_tmp = BeautifulSoup(html_tmp, 'html.parser')
    def extract_team_win(x):
        return [x[0].findAll('a')[0].getText().strip(), float(x[1].getText())]
    df = pd.DataFrame([extract_team_win(x.findAll('td')) for x in soup_tmp.findAll("tbody")[0].findAll('tr')], columns = ['Team', 'Win total'])
    df.set_index('Team', drop=True, inplace = True)
    df['Win total'] = df['Win total'].apply(lambda x: x / 10 if x > 100 else x)
    return df
